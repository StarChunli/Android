package com.example.http_3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.os.Handler;
import android.util.Log;
import android.webkit.WebView;

public class HttpThread extends Thread {
	private String url;
	private WebView webView;
	private Handler handler;
	
	public HttpThread(String url,WebView webView,Handler handler){
	this.url=url;
	this.webView=webView;
	this.webView.getSettings().setBlockNetworkImage(false);
	this.webView.getSettings().setJavaScriptEnabled(true);
	this.handler=handler;
	}
	
	@Override
	public void run(){
		try{
			URL httpUrl=new URL(url);
		try{
			HttpURLConnection conn=(HttpURLConnection)httpUrl.openConnection();
			conn.setReadTimeout(50000);//��ʱ����
			conn.setRequestMethod("GET");
			final StringBuffer sb=new StringBuffer();//����
			Log.i("123","1");
			BufferedReader reader= new BufferedReader(new InputStreamReader(conn.getInputStream()));//������
			Log.i("123","2");
			String str;
			while((str = reader.readLine())!=null){
				sb.append(str);
			}
			Log.i("123","3");
			handler.post(new Runnable(){
				@Override
				public void run(){
				//TODO Auto-generated method stub
					//webView.loadData(sb.toString(),"text/html;charset=utf-8",null);
					
			        webView.loadDataWithBaseURL("http://192.168.1.7/hotel_php/", sb.toString(), "text/html", "utf-8",null);

				}
			});
			Log.i("123","4");
			
		}catch(IOException e){
			e.printStackTrace();
			Log.i("exp",e.toString());
		}
}catch(MalformedURLException e){
	e.printStackTrace();
		}

	}
}

