package com.example.http_4;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.view.Menu;
import android.webkit.WebView;
import android.widget.ImageView;

public class MainActivity extends Activity {
	private WebView  webView;

	private Handler handler=new Handler();
	
	private ImageView imageView;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView=(WebView)findViewById(R.id.webView1);
        imageView=(ImageView)findViewById(R.id.imageView1);
		new HttpThread("https://www.baidu.com/img/bd_logo1.png",imageView,(Handler) handler).start();
        //new HttpThread("http://",imageView,(Handler) handler).start();
        
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
