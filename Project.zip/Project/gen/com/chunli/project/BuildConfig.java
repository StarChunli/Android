/** Automatically generated file. DO NOT MODIFY */
package com.chunli.project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}