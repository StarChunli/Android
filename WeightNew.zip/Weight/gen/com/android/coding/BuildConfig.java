/** Automatically generated file. DO NOT MODIFY */
package com.android.coding;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}