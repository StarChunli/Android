package andy.ham;



import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;

public class Access extends Activity {
	
	private Button access;
	private SharedPreferences sp=null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.access);
		
		access = (Button)findViewById(R.id.access);
		access.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent = null;
				intent = new Intent(Access.this, LifeDiary.class);  
			    startActivity(intent);
			    overridePendingTransition(android.R.anim.slide_in_left,android.R.anim.slide_out_right);
			    Access.this.finish();
			}
		});
	}

}
