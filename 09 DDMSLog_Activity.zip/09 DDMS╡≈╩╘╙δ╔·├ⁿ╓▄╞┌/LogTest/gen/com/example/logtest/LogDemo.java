package com.example.logtest;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class LogDemo extends Activity{
	private static String ACTIVITY_IAG = "LogDemo";
	private Button bt;
	public void onCrate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		bt = (Button) findViewById(R.id.button1);
		bt.setOnClickListener(new Button.OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Log.v(LogDemo.ACTIVITY_IAG, "this is verbose");
				Log.d(LogDemo.ACTIVITY_IAG, "this is debug");
				Log.i(LogDemo.ACTIVITY_IAG, "this is information");
				Log.w(LogDemo.ACTIVITY_IAG, "this is warnning.");
				Log.e(LogDemo.ACTIVITY_IAG, "this is error.");
			}
		});
	}
}
